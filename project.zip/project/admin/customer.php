<?php require_once('database/dbhelper.php'); ?>
<!DOCTYPE html>
<html>

<head>
    <title>Quản Lý Khách Hàng</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <ul class="nav nav-tabs">
    
        <li class="nav-item">
            <a class="nav-link" href="category/index.php">Thống kê</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="category/index.php">Quản lý danh mục</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="product/">Quản lý sản phẩm</a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="dashboard.php">Quản lý giỏ hàng</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="customer.php">Quản lý khách hàng</a>
        </li>
    </ul>
    <div class="container">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h2 class="text-center">Quản lý khách hàng</h2>
            </div>
            <div class="panel-body">
                <a href="../login/reg.php">
                    <button id="add_customer" style="margin-bottom:20px">Thêm khách hàng</button>
                </a>
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <td width="70px">STT</td>
                            <td>Tên khách hàng</td>
                            <td>Tên Tài khoản</td>
                            <td>Điện thoại</td>
                            <td>Email</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Lấy danh sách khách hàng
                        $sql = 'SELECT * FROM user';
                        $userList = executeResult($sql);
                        $index = 1;

                        if (!empty($userList)) {
                            foreach ($userList as $user) {
                                echo '<tr>
                                    <td>' . ($index++) . '</td>
                                    <td>' . $user['hoten'] . '</td>
                                    <td>' . $user['username'] . '</td>
                                    <td>' . $user['phone'] . '</td>
                                    <td>' . $user['email'] . '</td>
                                </tr>';
                            }
                        } else {
                            echo '<tr><td colspan="5" class="text-center">Không có khách hàng nào</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        document.getElementById('add_customer').addEventListener('click', function() {
            console.log('Đã ấn');
            window.location.href = '../login/reg.php';
        });
    </script>
</body>

</html>
