<?php
define('HOST', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '310802');
define('DATABASE', 'asm_php1');