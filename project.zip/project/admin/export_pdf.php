<?php
require_once 'vendor/autoload.php';

// Tạo một đối tượng mpdf
$mpdf = new Mpdf();

// Lấy HTML của trang web của bạn
ob_start();
include __DIR__ . '/revenue_content.php'; // Sử dụng đường dẫn tương đối hoặc tuyệt đối tới tệp revenue_content.php
$html = ob_get_clean(); 

// Thêm HTML vào mpdf để tạo tệp PDF
$mpdf->WriteHTML($html);

// Thiết lập headers cho file PDF
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="revenue_report.pdf"');

// Output file PDF
$mpdf->Output();
?>
