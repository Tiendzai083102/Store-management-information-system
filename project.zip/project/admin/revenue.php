<?php
require_once('database/dbhelper.php');
// Mảng để lưu tổng tiền của mỗi loại mặt hàng
$totalAmounts = array(
    'tra_sua' => 0,
    'coffe' => 0,
    'sinh_to' => 0,
    'do_an_vat' => 0
);

// Truy vấn tổng tiền cho từng mặt hàng
$queries = [
    'tra_sua' => "SELECT SUM(order_details.num * order_details.price) AS total
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    WHERE product.id_category = 1;
    ",
    'coffe' => "SELECT SUM(order_details.num * order_details.price) AS total
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    WHERE product.id_category = 2;
    ",
    'sinh_to' => "SELECT SUM(order_details.num * order_details.price) AS total
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    WHERE product.id_category = 3;
    ",
    'do_an_vat' => "SELECT SUM(order_details.num * order_details.price) AS total
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    WHERE product.id_category = 4;
    "
];
$tongsl=[
    'tra_sua' => "SELECT SUM(order_detail.num) AS total
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    WHERE product.id_category = 1;
    ",
    'coffe' => "SELECT SUM(order_detail.num) AS total
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    WHERE product.id_category = 2;
    ",
    'sinh_to' => "SELECT SUM(order_detail.num) AS total
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    WHERE product.id_category = 3;
    ",
    'do_an_vat' => "SELECT SUM(order_details.num * order_details.price) AS total
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    WHERE product.id_category = 4;
    "  
];
$topProductsQuery = "
    SELECT product.title, category.name AS category_name, SUM(order_details.num) AS total_quantity, SUM(order_details.num * order_details.price) AS total_revenue
    FROM order_details
    JOIN product ON order_details.product_id = product.id
    JOIN category ON product.id_category = category.id
    GROUP BY product.id
    ORDER BY total_quantity DESC
    LIMIT 3;
";
$topProductsResult = executeResult($topProductsQuery);



// Khởi tạo mảng để lưu trữ top 3 sản phẩm bán chạy nhất
$topProducts = array();

// Kiểm tra xem kết quả truy vấn có dữ liệu hay không
if ($topProductsResult && !empty($topProductsResult)) {
    // Duyệt qua từng dòng kết quả và thêm vào mảng topProducts
    foreach ($topProductsResult as $product) {
        $productInfo = array(
            'title' => $product['title'],
            'category_name' => $product['category_name'],
            'total_quantity' => $product['total_quantity'],
            'total_revenue' => $product['total_revenue']
        );
        $topProducts[] = $productInfo;
    }
}
$totalProductQuery="SELECT SUM(order_details.num) AS total_quantity FROM order_details";
$result = executeSingleResult($totalProductQuery);

// Kiểm tra nếu có kết quả
if ($result) {
    // Lấy tổng số lượng sản phẩm đã bán từ kết quả
    $totalQuantity = $result['total_quantity'];
} else {
    // Nếu không có kết quả, gán tổng số lượng sản phẩm đã bán là 0
    $totalQuantity = 0;
}

// Hiển thị thông tin top 3 sản phẩm bán chạy nhất

foreach ($queries as $key => $query) {
    $result = executeResult($query); // Thay đổi dòng này
    if ($result && !empty($result)) {
        $totalAmounts[$key] = $result[0]['total']; // Chỉ lấy giá trị đầu tiên
    } else {
        $totalAmounts[$key] = 0; // Gán giá trị 0 nếu không có kết quả hoặc kết quả rỗng
    }
}

// Kiểm tra và gán giá trị 0 cho các mặt hàng không có giá trị
foreach ($totalAmounts as $key => $total) {
    if (!isset($total)) {
        $totalAmounts[$key] = 0;
    }
}
$totalRevenue = array_sum($totalAmounts);
// In ra tổng tiền của mỗi mặt hàng
$percentages = [];
foreach ($totalAmounts as $key => $total) {
    $percentage = ($total / $totalRevenue) * 100;
    $percentages[$key] = $percentage;
}

?>
<!DOCTYPE HTML>
<html>
<head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var traSua = <?php echo $percentages['tra_sua']; ?>;
            var coffe = <?php echo $percentages['coffe']; ?>;
            var sinhTo = <?php echo $percentages['sinh_to']; ?>;
            var doAnVat = <?php echo $percentages['do_an_vat']; ?>;

            var dataPie = google.visualization.arrayToDataTable([
                ['Mặt hàng', 'Phần trăm'],
                ['Trà Sữa', traSua],
                ['Coffe', coffe],
                ['Sinh Tố', sinhTo],
                ['Đồ Ăn Vặt', doAnVat]
            ]);

            var dataColumn = google.visualization.arrayToDataTable([
                ['Mặt hàng', 'Tổng tiền'],
                <?php foreach ($totalAmounts as $key => $total): ?>
                    ['<?php echo ucfirst(str_replace('_', ' ', $key)); ?>', <?php echo $total; ?>],
                <?php endforeach; ?>
            ]);

            var optionsPie = {
                title: 'Phần trăm doanh thu của các danh mục',
                animationEnabled: true,
                startAngle: 240,
                yValueFormatString: "##0.00\"%\"",
                indexLabel: "{label} {y}"
            };

            var optionsColumn = {
                title: 'Tổng tiền các mặt hàng',
                legend: { position: 'none' },
                width: 300,
                height: 300
            };

            var chartPie = new google.visualization.PieChart(document.getElementById('pie_chart'));
            var chartColumn = new google.visualization.ColumnChart(document.getElementById('column_chart'));

            chartPie.draw(dataPie, optionsPie);
            chartColumn.draw(dataColumn, optionsColumn);
        }

    </script>
    <style>
        #exportPdfButton {
        position: fixed; /* Đặt vị trí cố định */   
        top: 20px; /* Khoảng cách từ trên xuống */
        right: 20px; /* Khoảng cách từ phải sang trái */
        z-index: 9999; /* Đảm bảo nút nằm trên cùng */
        background:red;
        }
        .total-revenue, .total-quantity {
            text-align: center;
            font-size: 20px;
            margin-bottom: 20px;
            margin-left:10px;
            padding: 10px;
            border: 1px solid #ddd;
            display: inline-block;
        }
        .charts-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap; /* Cho phép các biểu đồ trên cùng một dòng */
        }
        .chart {
            width: 45%;
            margin-bottom: 20px; /* Khoảng cách giữa biểu đồ */
        }
        .topic {
            color: red;
            text-align: center;
            margin-top: 20px; /* Khoảng cách giữa tiêu đề và biểu đồ */
        }
        .top-products-table {
            margin: auto; /* Đưa bảng vào giữa */
            margin-top: 20px; /* Khoảng cách giữa bảng và biểu đồ */
            border-collapse: collapse;
            width: 70%; /* Chiều rộng của bảng */
        }
        .top-products-table th, .top-products-table td {
            border: 1px solid #dddddd;
            padding: 8px;
            text-align: left;
        }
        .top-products-table th {
            background-color: #f2f2f2;
        }
        .title3{
            text-align: center;
        }
    </style>
</head>
<body>
    <h1 class="topic">
        Thống kê doanh thu của quán
    </h1>  
     <div class="total-revenue">
        <strong>Tổng doanh thu:</strong> 
        <?php echo number_format($totalRevenue, 0, ',', '.'); ?> VND
    </div>
    <div class="total-quantity">
        <strong>Tổng sản phẩm đã bán:</strong> 
        <?php echo $totalQuantity ?>
    </div>
    <button id="exportPdfButton" type="button">Xuất PDF</button>
    <div class="charts-container">
        <div id="pie_chart" class="chart"></div>
        <div id="column_chart" class="chart"></div>
    </div>
        
    <table class="top-products-table">
    <h2 class="title3">Top 3 sản phẩm bán chạy nhất của cửa hàng</h2>
        <tr>
            <th>Sản phẩm</th>
            <th>Danh mục</th>
            <th>Số lượng bán</th>
            <th>Doanh thu</th>
        </tr>
        <?php foreach ($topProducts as $product): ?>
        <tr>
            <td><?php echo $product['title']; ?></td>
            <td><?php echo $product['category_name']; ?></td>
            <td><?php echo $product['total_quantity']; ?></td>
            <td><?php echo number_format($product['total_revenue'], 0, ',', '.'); ?> VND</td>
        </tr>
        <?php endforeach; ?>
    </table>
    <script type="text/javascript">
        document.getElementById('exportPdfButton').addEventListener('click', function() {
            console.log('Đã ấn');
            window.location.href = 'export_pdf.php'; // Thay đổi 'export_pdf.php' bằng tên tệp PHP bạn đã tạo để tạo và xuất PDF.
        });
    </script>
</body>
</html>

